import Cookies from "js-cookie";

export const createNewAdoption = async (formData) => {
  try {
    const res = await fetch("/api/adoption/create-adoption", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${Cookies.get("token")}`,
      },
      body: JSON.stringify(formData),
    });

    const data = await res.json();

    return data;
  } catch (e) {
    console.log(e);
  }
};

export const getAllAdoptionsForUser = async (id) => {
  try {
    const res = await fetch(`/api/adoption/get-all-adoptions?id=${id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${Cookies.get("token")}`,
      },
    });

    const data = await res.json();

    return data;
  } catch (e) {
    console.log(e);
  }
};

export const getAdoptionDetails = async (id) => {
  try {
    const res = await fetch(`/api/adoption/adoption-details?id=${id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${Cookies.get("token")}`,
      },
    });

    const data = await res.json();

    return data;
  } catch (e) {
    console.log(e);
  }
};

export const getAllAdoptionsForAllUsers = async () => {
  try {
    const res = await fetch(`/api/admin/adoptions/get-all-adoptions`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${Cookies.get("token")}`,
      },
    });

    const data = await res.json();

    return data;
  } catch (e) {
    console.log(e);
  }
};

export const updateStatusOfAdoption = async (formData) => {
  try {
    const res = await fetch(`/api/admin/adoptions/update-adoption`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${Cookies.get("token")}`,
      },
      body: JSON.stringify(formData),
    });

    const data = await res.json();

    return data;
  } catch (e) {
    console.log(e);
  }
};
