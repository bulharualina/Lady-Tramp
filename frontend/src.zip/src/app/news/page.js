export default function News() {
  return <div className="text-black">News</div>;
}
